# TapType
